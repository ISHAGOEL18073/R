install.packages("installr"); 
library(installr) # install+load installr
updateR() # updating R.
