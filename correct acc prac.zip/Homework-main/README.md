A place for homework and nothing else!!
